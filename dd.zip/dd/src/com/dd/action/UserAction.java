package com.dd.action;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.SessionAware;  
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.dd.dao.Userdao;
import com.dd.model.User;
import com.opensymphony.xwork2.ActionSupport;


@Controller @Scope("prototype")

public class UserAction extends ActionSupport implements SessionAware{
	


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*ҵ������*/
    @Resource Userdao userdao;
    
    private User user;
    
    //��������Ա��������������¼���صģ��ǵ�����setter��getter
    
	private Map<String,Object> session;

	public User getCustomer() {
		return user;
	}

	public void setCustomer(User customer) {
		this.user = customer;
	}
	
	public Map<String, Object> getSession() {
		return session;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	
	
	private String errMessage;
	
	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	
	/*
	public String reg() throws Exception{
		customerDao.AddCustomer(customer);
		session.put("curCustomer", customer);
		return "show_view";
		
	}*/
	
    //ע�ᣬ����session�м����û���
	public String reg() throws Exception{
		userdao.AddCustomer(user);
		session.put("user", user);
		return "succseereg";

	}
    
	/* ��֤�û���¼ */
	/*public String login() {
		Customer db_customer = (Customer)customerDao.QueryCustomerInfo(customer.getName()).get(0);
		if(db_customer == null) { 
			
			this.errMessage = " �˺Ų����� ";
			System.out.print(this.errMessage);
			return INPUT;
			
		} else if( !db_customer.getPassword().equals(customer.getPassword())) {
			
			this.errMessage = " ���벻��ȷ! ";
			System.out.print(this.errMessage);
			return INPUT;
			
		}else{
			return "show_view";
			
		}	*/	

	
		/* ��֤�û���¼ */
		public String login() {
			
			ArrayList<User> listCustomer = userdao.QueryCustomerInfo(user.getUname());
			if(listCustomer.size()==0) { 
				
				this.errMessage = " �˺Ų����� ";
				System.out.print(this.errMessage);
				return "input";
				
			} 
			else{
				
			   User db_customer = listCustomer.get(0);
				if(!db_customer.getPasswd().equals(user.getPasswd())) {
				
					this.errMessage = " ���벻��ȷ! ";
					System.out.print(this.errMessage);
					return "input";
				
			    }else{
				
					session.put("user", db_customer);
					return "success";
			    }
			}
		}


}